#!/usr/bin/env bash
# setup.sh -- one-shot environment setup. Safe to re-run.
#
#   bash setup.sh
#
set -e

echo "=== Kalshi BTC bot :: environment setup ==="
echo

echo "[1/5] installing system packages (needs sudo)..."
sudo apt update -qq
sudo apt install -y python3-venv python3-pip tmux chrony unzip curl >/dev/null
echo "      done"

echo "[2/5] enabling clock sync (tau accuracy depends on this)..."
sudo systemctl enable chrony >/dev/null 2>&1 || true
sudo systemctl restart chrony
sleep 2
chronyc tracking | head -3 || true

echo "[3/5] creating folders..."
mkdir -p data out scripts
echo "      done"

echo "[4/5] creating python venv + installing libraries..."
if [ ! -d .venv ]; then
  python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet pandas numpy openpyxl requests cryptography
echo "      done"

echo "[5/5] verifying..."
python3 - <<'PYEOF'
import pandas, numpy, openpyxl, requests, cryptography
print("      libraries OK")
PYEOF

echo
echo "=== setup complete ==="
echo
echo "IMPORTANT: every new terminal needs this first:"
echo "    cd ~/kalshi-btc && source .venv/bin/activate"
echo
echo "Next: python3 scripts/kalshi_discover.py"